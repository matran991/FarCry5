//var $urlUpdate = "https://script.google.com/macros/s/AKfycbws1XUDXNrAXl5M-88-EnhIxQIybpHJpeKflSc0irTVvPF5jaU/exec?type=DarkS3";
$RunClick = false;
$checkAudio = ""
$mouse = false;
function RemovePatch($check){
	if($RunClick == false){
		alert("Đang trong tiến trình tải patch.<br>Bạn không được phép dùng thao tác này.");
		return false;
	}
	// Chạy script Backup
	if($check == false){
		execscript('Backup("'+$JSON[12]+'","Res","'+$JSON[10]+'")');
	}
	else{
		alert("Đã xóa patch việt hóa.<br><br>Các bạn có thể cài lại bất cứ khi nào.")
	}
}

function textDot($text){
	var $string = $text.split("");
	$number = 0;
	var $max = $string.length;
	$('.dot-load').text("");	
	if(typeof($dotLoop) !== 'undefined'){
		clearInterval($dotLoop);
	}
	$dotLoop = setInterval(function(){
		if($number < $max){
			//var $char = $string[$number];
			//$number += 1;
			//$('.dot-load').append($char);
			document.getElementById("dot-write").innerHTML += $text.charAt($number);
			$number++;
		}
		else{
			//clearInterval($dotLoop);
			setTimeout(function(){
				$number = 0;
				document.getElementById("dot-write").innerHTML = "";
			},3000);
		}
	},100);
}

function UpdateDL($percent,$byte){
	$percent = Number($percent);
	$byte = Number($byte);
	if($percent >= 100){
		$percent = 100;
	}
	var $mb = ($byte / 1000000).toFixed(1);
	$(".percent-background").css("width",$percent + "%");
	$('.number-download').text($mb);
	$('.percent-number').text($percent + "%")
	//alert($value);
}

function EndPatch(){
	$('.popup-layout').removeClass("loading");
	var $text = "Xin Chúc Mừng!<br><br>";
	$text += "Bạn đã cài patch thành công. Chúc bạn trải nghiệm game thật là vui vẻ.";
	alert($text);
	$('#RunPatch').removeClass("RunDL");
	$RunClick = true;
}

function getUpdate(){
	$JSON1 = $('#JSON').text();
	$JSON = $JSON1.split("||");
	thongbao($JSON);
	addLink($JSON);
	$RunClick = true;
}

function matran999(){
	execscript('OpenWeb("https://gametiengviet.com/members/matran999.1728/")');
}

function openForum(){
	execscript('OpenWeb("'+$JSON[8]+'")');
}

function checkLink($link1,$link2,$link3){

	if($link1.indexOf("hientrang=TRUE") == -1){
		$('.list-credit .server-item .active').removeClass("active");
		$('.server1').attr("disable","disable");
		$('.server2 .check-server').addClass("active");
		if($link2.indexOf("hientrang=TRUE") == -1){
			$('.list-credit .server-item .active').removeClass("active");
			$('.server2').attr("disable","disable");
			$('.server3 .check-server').addClass("active");
			if($link3.indexOf("hientrang=TRUE") == -1){
				$('.list-credit .server-item .active').removeClass("active");
				$('.server3').attr("disable","disable");			
				alert("Tất cả link download đều hỏng.<br>Hệ thống sẽ thử truy cập lại server.<br>Nếu vẫn lỗi, vui lòng liên hệ Matran999 để fix link");
			}
		}
	}
	if($link2.indexOf("hientrang=TRUE") == -1){
		$('.list-credit .server-item .active').removeClass("active");
		$('.server2').attr("disable","disable");
		$('.server3 .check-server').addClass("active");
		if($link3.indexOf("hientrang=TRUE") == -1){
			$('.list-credit .server-item .active').removeClass("active");
			$('.server3').attr("disable","disable");
			$('.server1 .check-server').addClass("active");
			if($link1.indexOf("hientrang=TRUE") == -1){
				$('#RunPatch').attr("disable","disable");
				$('.list-credit .server-item .active').removeClass("active");
				$('.server1').attr("disable","disable");			
				alert("Tất cả link download đều hỏng.<br>Hệ thống sẽ thử truy cập lại server.<br>Nếu vẫn lỗi, vui lòng liên hệ Matran999 để fix link");
			}
		}
	}
	if($link3.indexOf("hientrang=TRUE") == -1){
		$('.list-credit .server-item .active').removeClass("active");
		$('.server3').attr("disable","disable");
		$('.server1 .check-server').addClass("active");
		if($link1.indexOf("hientrang=TRUE") == -1){
			$('.list-credit .server-item .active').removeClass("active");
			$('.server1').attr("disable","disable");
			$('.server2 .check-server').addClass("active");
			if($link2.indexOf("hientrang=TRUE") == -1){
				$('#RunPatch').attr("disable","disable")
				$('.list-credit .server-item .active').removeClass("active");
				$('.server2').attr("disable","disable");			
				alert("Tất cả link download đều hỏng.<br>Hệ thống sẽ thử truy cập lại server.<br>Nếu vẫn lỗi, vui lòng liên hệ Matran999 để fix link");
			}
		}
	}
}

function addLink($JSON){
	var $forum = $JSON[8];
	var $gameVersion = $("#version-game").val();
	if($gameVersion == 1){
		$('#sizeFile').val($JSON[9]);
		var $size = ($JSON[9] / 1000000).toFixed(1);	
		checkLink($JSON[4],$JSON[5],$JSON[6])
		$('#server1').val($JSON[4]);
		$('#server2').val($JSON[5]);
		$('#server3').val($JSON[6]);
		$('.number-limit').text($size);
	}
	// Nếu là bản Limited
	if($gameVersion == 2){
		$('#sizeFile').val($JSON[16]);
		var $size = ($JSON[16] / 1000000).toFixed(1);
		checkLink($JSON[13],$JSON[14],$JSON[15]);
		$('#server1').val($JSON[13]);
		$('#server2').val($JSON[14]);
		$('#server3').val($JSON[15]);
		$('.number-limit').text($size);
		$('.check-version.active').removeClass("active");
		$('.version2 .check-version').addClass("active");
		//alert($JSON[13] + "<br>" + $JSON[16]);
	}
	
	$('#location').val($JSON[10]);
	$('#zipname').val($JSON[11]);
	$('#listFile').val($JSON[12]);
	$('#version-new').val($JSON[1]);
	$('#forum').val($forum);	
	$('.count-download').text(Number($JSON[7]).toLocaleString().replace(/\.\d+/,""));
	textDot("Đang Chờ...")
	// Kiểm tra xem phiên bản nào;

	
}

function thongbao($JSON){
	var $oldVersion = $('#version-old').val();
	//alert($oldVersion + "|" + $JSON[1]);
	if($JSON[1] == $oldVersion){
		//console.log("Cùng phiên bản, không hiện thông báo");
		$('.number-version').text($JSON[1]);
	}
	else{
		//console.log("Khác phiên bản, hiện thông báo");
		$('.tab-content').html($JSON[3].replace(/<lf>/gi,"<br>"));
		$('.number-version').text($JSON[1]);
		$('.popup-layout').addClass("text-alert");
		$('#RunPatch').html("CẬP NHẬT PHIÊN BẢN MỚI<span class=\"bk-hover\">a</span>");
	}
	
}

function checkBox($el){
	var $boxClass = $($el).attr("class");
	if($boxClass.indexOf("agree-check") > -1){
		var $end = $('.faq-scroll')[0].scrollHeight - $('.faq-scroll').height() - 200;
		var $top = $(".faq-scroll").scrollTop();
		var $box = $($el).find(".input-checkbox");
		var $sclass = $box.attr("class");
		if($sclass.indexOf("active") > -1){
			$box.removeClass("active");
		}
		else{
			if($top < $end){
				alert("Vui lòng đọc hết quy định của nhóm");
			}
			else{
				$box.addClass("active");
			}	
		}
	}
	else{
		var $box = $($el).find(".input-checkbox");
		var $sclass = $box.attr("class");
		if($sclass.indexOf("active") > -1){
			$box.removeClass("active");
		}
		else{
			$box.addClass("active");
		}
	}
}

function checkRadio($el){
	var $hclass = $($el).attr("class");
	var $box = $($el).find(".input-checkbox");
	var $dis = $($el).attr("disable");
	if($dis){
		alert("Server này đã bị hỏng, vui lòng chọn server khác");
	}
	else{
		if($hclass.indexOf("version") > -1){
			alert("Bạn đang chọn một phiên bản khác với hệ thống nhận diện.<br>Hãy chắc rằng mình chọn đúng phiên bản, vì có thể sẽ xảy ra lỗi nếu cài sai phiên bản.");
			var $ver = $box.attr("alt");
			$("#version-game").val($ver);
			addLink($JSON);
		}
		var $sclass = $box.attr("class");
		$($el).parent().find(".active").removeClass("active");
		$box.addClass("active");
	}

}

function popupClick($el){
	var $box = $($el).attr("class");
	//if($box.indexOf("text-alert") > -1 ){
		$($el).removeClass("text-alert");
	//}
}

function playMusic($el){
		var $class = $($el).attr("class");
		if($class.indexOf("playmusic") > -1){
			$(".speaker").removeClass("playmusic")
			$('#player')[0].pause();
			clearInterval($checkAudio);
		}
		else{
			$(".speaker").addClass("playmusic")
			$('#player')[0].play();
			UpdateMusic();
		}
}

function UpdateMusic(){
	$checkAudio = setInterval(function(){
		var $timeplay = $('#player')[0].currentTime.toFixed(2);
		var $duration = $('#player')[0].duration.toFixed(2);;
		var $percent = (Math.floor($timeplay) / Math.floor($duration)) * 100
		$(".progress-music").css("width",$percent + "%");
		//document.getElementsByClassName("progress-music")[0].style.width = $percent + "%"
		var $timeRun = ($timeplay / 60).toFixed(2) + ":" + ($duration / 60).toFixed(2);
		$(".TimeClap").text($timeRun);
		//document.getElementsByClassName("TimeClap")[0].innerText = $timeRun
		//console.log($percent);
		if($percent == 100){
			$(".progress-music").css("width","100%");
			//document.getElementsByClassName("progress-music")[0].style.width = "100%"
			$(".TimeClap").text(($duration / 60).toFixed(2) + ":" + ($duration / 60).toFixed(2));
			//document.getElementsByClassName("TimeClap")[0].innerText = 
			clearInterval($checkAudio);
			$('#player')[0].currentTime = 0;
			UpdateMusic();
		}
	
	},10)
}

function alert($text,$check){
	$('.tab-content').html($text);
	$('.popup-layout').addClass("text-alert");
}

function RunCheck(){
	var $linkdie = $('#RunPatch').attr("disable");
	if($linkdie){
		alert("Tất cả server đều hỏng, vui lòng liên hệ Matran999 để fix.<br><br>Xin cám ơn.");
		return false;
	}
	if($RunClick == false){
		alert("Vui lòng chờ...");
		return false;
	}
	// Kiểm tra xem người dùng đồng ý quy định chưa
	/*
	var $sclass = $('.check-faq').attr("class");
	if($sclass.indexOf("active") == -1){
		var $text = '<div class="tleft">Không thể chạy patch, bởi vì bạn chưa đồng ý với quy định của nhóm.<br>Các bạn vui lòng tích vào quy định để tiến hành patch.</div>';
		alert($text,true)
		return false;
	}
	*/
	//alert("Đang tải patch... Vui lòng chờ trong ít phút...");
	$RunClick = false;
	$('#RunPatch').addClass("RunDL")
	var $check = $('.check-desktop').attr("class");
	if($check.indexOf("active") > -1){
		var $desktop = "true";
	}
	else{
		var $desktop = "false";
	}
	
	var $server = $('.check-server.active').attr("alt");
	// Lấy link server
	var $serverlink = $('#server' + $server).val();
	// Lấy link forum
	var $fourm = $('#forum').val();
	// Lấy vị trí patch
	var $location = $('#location').val();
	// Lấy zip name
	var $zipname = $('#zipname').val();
	// Lấy size file
	var $sizeFile = $('#sizeFile').val();
	// Lấy List File
	var $listFile = $('#listFile').val();
	// Lấy phiên bản mới
	var $verNew = $('#version-new').val();
	//$('.popup-layout').addClass("loading");
	execscript('DownloadFIle("'+$serverlink+'","'+$location+'","'+$sizeFile+'","'+$fourm+'","'+$zipname+'","'+$desktop+'","'+$listFile+'","'+$verNew+'")');
	//execscript("RunPatch(\""+$value+"\")");
}
/*




*/

if($mouse == true){
	document.oncontextmenu = function() { return false; }
	document.ondragstart   = function() { return false; }
	document.onmousedown   = md;
}

function md(e) 
{ 
  try { if (event.button==2||event.button==3) return false; }  
  catch (e) { if (e.which == 3) return false; } 
}
function Goto($value){
	switch($value) {
		case 1:
			execscript('Goto("https://discord.gg/3SkGPy4")')
			break;
		case 2:
			execscript('Goto("https://gametiengviet.com/forums/")')
			break;
		case 3:
			execscript('Goto("https://www.facebook.com/gametiengviet/")')
			break;
	}
}

$(function(){

var $rateH = $(window).height()/1080;

$('.row3').css("transform","scale("+$rateH+")");
$('.row3').css("-ms-transform","scale("+$rateH+")");
var $number = 1;
getBegin();
UpdateMusic();
});

function getBegin(){
	$UpdateLoop = setInterval(function(){
		var $check = $('#JSON').text();
		if($check.length > 100){
			getUpdate();
			clearInterval($UpdateLoop);
			$('.popup-layout').removeClass("loading");
		}
	},100);
}




